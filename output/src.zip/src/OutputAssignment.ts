import {Assingment} from "./Assingment";

export class OutputAssignment {

    constructor(
        public assignments: Assingment[],
    ) {
    }

}
