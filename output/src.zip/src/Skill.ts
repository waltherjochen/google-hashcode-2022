export class Skill {

    constructor(
        public name: string,
        public level: number,
    ) {
    }

}
